//
//  HCPUpdateRequest.m
//
//  Created by Nikolay Demyankov on 24.05.16.
//

#import "HCPUpdateRequest.h"

@implementation HCPUpdateRequest

@end

//
//  AppsMobileCompany
//
//  Created by ___FULLUSERNAME___ on ___DATE___.
//  Copyright ___ORGANIZATIONNAME___ ___YEAR___. All rights reserved.
//

#ifndef Constants_h
#define Constants_h

FOUNDATION_EXPORT Boolean isPreview;
FOUNDATION_EXPORT NSString *appDomain;
FOUNDATION_EXPORT NSString *appKey;

#endif /* Constants_h */
